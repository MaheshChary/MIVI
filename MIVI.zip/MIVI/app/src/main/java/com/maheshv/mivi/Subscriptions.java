package com.maheshv.mivi;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.JsonReader;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

public class Subscriptions extends AppCompatActivity {

    private Context context = Subscriptions.this;

    private Dialog dialog = null;

    private LinearLayout linearLayout;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscriptions);

        linearLayout = findViewById(R.id.linearlayout_id);

        showProgress(getString(R.string.plwait));

        displayData(loadJSONFromAsset());
    }

    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = getAssets().open("collection.json");

            int size = is.available();

            byte[] buffer = new byte[size];

            is.read(buffer);

            is.close();

            json = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            dismissProgress();
            return null;
        }
        dismissProgress();
        return json;

    }

    private void showProgress(String title) {

        dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setBackgroundDrawable(
                new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(false);
        View view = View.inflate(context, R.layout.dialog_progress, null);
        dialog.setContentView(view);
        if (dialog != null)
            dialog.show();

    }

    private void dismissProgress() {
        try {

            if (dialog != null)
                dialog.dismiss();
            dialog = null;

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void displayData(String data){
        try{

            if(data!=null && !data.equalsIgnoreCase("")){

                JSONObject jsonObject = new JSONObject(data);

                if(jsonObject.has("data")){

                    JSONObject dataObj = jsonObject.optJSONObject("data");

                    if(dataObj.has("attributes")){

                        JSONObject attrs = dataObj.optJSONObject("attributes");

                        if(attrs.length() >0){

                            TextView tvdetails = new TextView(context);

                            tvdetails.setText(getString(R.string.details_text)
                            .replace("(NAME)", attrs.optString("title")+". "
                            + attrs.optString("first-name") +" "+attrs.optString("last-name"))
                            .replace("(DETAILS)",attrs.optString("email-address"))
                                    .replace("(MOBILE)",attrs.optString("contact-number"))
                                    .replace("(TYPE)",attrs.optString("payment-type")));

                            tvdetails.setTextSize(22);

                            linearLayout.addView(tvdetails);

                            View view = new View(context);

                            view.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

                            view.setBackgroundColor(Color.BLACK);

                            linearLayout.addView(view);

                        }

                    }
                }

                if(jsonObject.has("included")){

                    JSONArray jsonArray = jsonObject.optJSONArray("included");

                    if(jsonArray.length()>0){

                        JSONObject subsJson = jsonArray.optJSONObject(1);

                        if(subsJson.has("attributes")){

                            JSONObject attrsObj = subsJson.optJSONObject("attributes");

                            TextView tvsubs = new TextView(context);

                            tvsubs.setText(getString(R.string.sub_text)
                                    .replace("(BALANCE)", attrsObj.optString("included-data-balance"))
                                    .replace("(DATE)",attrsObj.optString("expiry-date")));

                            tvsubs.setTextSize(22);

                            linearLayout.addView(tvsubs);

                            View view = new View(context);

                            view.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

                            view.setBackgroundColor(Color.BLACK);

                            linearLayout.addView(view);

                        }

                        JSONObject prodJson = jsonArray.optJSONObject(2);

                        if(subsJson.has("attributes")){

                            JSONObject attrsObj = prodJson.optJSONObject("attributes");

                            TextView tvsubs = new TextView(context);

                            tvsubs.setText(getString(R.string.pro_text)
                                    .replace("(NAME)", attrsObj.optString("name"))
                                    .replace("(PRICE)",attrsObj.optString("price")));

                            tvsubs.setTextSize(22);

                            linearLayout.addView(tvsubs);

                            View view = new View(context);

                            view.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1));

                            view.setBackgroundColor(Color.BLACK);

                            linearLayout.addView(view);

                        }
                    }
                }

            }
        }catch (Exception e){

        }
    }
}


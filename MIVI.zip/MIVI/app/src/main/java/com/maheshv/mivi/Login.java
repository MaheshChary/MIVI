package com.maheshv.mivi;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

public class Login extends AppCompatActivity {

    private Context context = Login.this;

    private EditText et_mobileno, et_otp;

    private TextView tv_sendotp, tv_resendotp, tv_proceed;

    private String number, otp;

    private View til_otp, iv_appicon;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        tv_sendotp = findViewById(R.id.tv_sendotp);
        tv_sendotp.setOnClickListener(onClick);

        tv_resendotp = findViewById(R.id.tv_resendotp);
        tv_resendotp.setOnClickListener(onClick);

        tv_proceed = findViewById(R.id.tv_proceed);
        tv_proceed.setOnClickListener(onClick);

        et_mobileno = findViewById(R.id.et_mobileno);
        et_mobileno.addTextChangedListener(phoneNumberWatcher);

        et_otp = findViewById(R.id.et_otp);
        et_otp.addTextChangedListener(OTPWatcher);

        til_otp = findViewById(R.id.til_otp);
        iv_appicon = findViewById(R.id.iv_appicon);
    }

    View.OnClickListener onClick = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.tv_sendotp:
                case R.id.tv_resendotp:
                    validateMobileNumber(et_mobileno.getText().toString());
                    break;
                case R.id.tv_proceed:
                    if (et_otp.getText().toString().length() == 0) {
                        showEditTextError(et_otp, getString(R.string.peotp));
                        return;
                    }
                    if (et_otp.getText().toString().length() < 4) {
                        showEditTextError(et_otp, getString(R.string.pevotp));
                        return;
                    }
                    sendOTPValidationRequest();
                    break;
                default:
                    break;
            }

        }
    };

    private final TextWatcher OTPWatcher = new TextWatcher() {

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            if (s.length() < 4) {
                et_otp.setOnEditorActionListener(null);
                return;
            }
            otp = s.toString();
            tv_proceed.setEnabled(true);
            et_otp.setOnEditorActionListener(et_otpAction);
        }
    };

    private void validateMobileNumber(String s) {
        if (s.length() == 0) {
            showEditTextError(et_mobileno, getString(R.string.peMsisdn));
            return;
        }
        if (s.length() < 10) {
            til_otp.setVisibility(View.GONE);
            tv_sendotp.setVisibility(View.VISIBLE);
            tv_proceed.setVisibility(View.GONE);
            tv_resendotp.setVisibility(View.GONE);
            et_otp.setText("");
            et_mobileno.setOnEditorActionListener(null);
            showEditTextError(et_mobileno, getString(R.string.peavmn));
            return;
        }
        number = s;
        if (number.length() == 10 && number.startsWith("0")) {
            showEditTextError(et_mobileno, getString(R.string.peavmn));
        } else if (number.length() == 10) {
            number = "91" + number;
            tv_sendotp.setEnabled(true);
            et_mobileno.setOnEditorActionListener(et_mobilenoAction);
            sendLoginRequest();
        } else if (number.length() == 11 && number.startsWith("0")) {
            number = number.substring(1);
            number = "91" + number;
            tv_sendotp.setEnabled(true);
            et_mobileno.setOnEditorActionListener(et_mobilenoAction);
                sendLoginRequest();
        } else if (number.length() == 11 && !number.startsWith("0")) {
            showEditTextError(et_mobileno, getString(R.string.peavmn));
        } else if (number.length() == 12 && number.startsWith("91")) {
            tv_sendotp.setEnabled(true);
            et_mobileno.setOnEditorActionListener(et_mobilenoAction);
                sendLoginRequest();
        } else if (number.length() == 12 && !(number.startsWith("91"))) {
            showEditTextError(et_mobileno, getString(R.string.peavmn));
        }
    }

    private void showEditTextError(EditText editText, String error) {
        editText.setError(error);
    }

    private void sendLoginRequest() {

        til_otp.setVisibility(View.VISIBLE);
        et_otp.requestFocus();
        tv_sendotp.setVisibility(View.INVISIBLE);
        tv_proceed.setVisibility(View.VISIBLE);
        tv_resendotp.setVisibility(View.VISIBLE);

    }

    TextView.OnEditorActionListener et_mobilenoAction = new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                sendLoginRequest();
            }
            return false;
        }
    };

    TextView.OnEditorActionListener et_otpAction = new TextView.OnEditorActionListener() {
        public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
            if ((event != null && (event.getKeyCode() == KeyEvent.KEYCODE_ENTER)) || (actionId == EditorInfo.IME_ACTION_DONE)) {
                sendOTPValidationRequest();
            }
            return false;
        }
    };

    private final TextWatcher phoneNumberWatcher = new TextWatcher() {

        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
        }

        public void onTextChanged(CharSequence s, int start, int before, int count) {
        }

        public void afterTextChanged(Editable s) {
            if (s.length() < 10) {
                til_otp.setVisibility(View.GONE);
                tv_sendotp.setVisibility(View.VISIBLE);
                tv_proceed.setVisibility(View.GONE);
                tv_resendotp.setVisibility(View.GONE);
                tv_sendotp.setEnabled(false);
                et_otp.setText("");
                et_mobileno.setOnEditorActionListener(null);
                showEditTextError(et_mobileno, getString(R.string.peavmn));
                return;
            }
            number = s.toString();
            if (number.length() == 10 && number.startsWith("0")) {
                showEditTextError(et_mobileno, getString(R.string.peavmn));
                tv_sendotp.setEnabled(false);
                return;
            } else if (number.length() == 10) {
                number = "91" + number;
                tv_sendotp.setEnabled(true);
                et_mobileno.setOnEditorActionListener(et_mobilenoAction);
                return;
            } else if (number.length() == 11 && number.startsWith("0")) {
                number = number.substring(1);
                number = "91" + number;
                tv_sendotp.setEnabled(true);
                et_mobileno.setOnEditorActionListener(et_mobilenoAction);
                return;
            } else if (number.length() == 11 && !number.startsWith("0")) {
                showEditTextError(et_mobileno, getString(R.string.peavmn));
                tv_sendotp.setEnabled(false);
                return;
            } else if (number.length() == 12 && number.startsWith("91")) {
                tv_sendotp.setEnabled(true);
                et_mobileno.setOnEditorActionListener(et_mobilenoAction);
                return;
            } else if (number.length() == 12 && !(number.startsWith("91"))) {
                showEditTextError(et_mobileno, getString(R.string.peavmn));
                tv_sendotp.setEnabled(false);
                return;
            }
            tv_sendotp.setEnabled(false);
        }
    };

    private void sendOTPValidationRequest() {
      startActivity(new Intent(context, Subscriptions.class)
              .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
      finish();
    }
}
